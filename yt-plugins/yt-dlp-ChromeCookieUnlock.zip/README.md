A [yt-dlp plugin](https://github.com/yt-dlp/yt-dlp#plugins) that allows unlocking the cookie database for chromium-based browsers.

Based on the work of [Charles Machalow](https://github.com/csm10495) [here](https://gist.github.com/csm10495/e89e660ffee0030e8ef410b793ad6a7e).

See [installing yt-dlp plugins](https://github.com/yt-dlp/yt-dlp#installing-plugins) for how this plugin package can be installed.
